<?php
define('CONSUMER_KEY', '4NOQELj8kqZMVAGh7101Q6XEd9AjbpZc');
define('CONSUMER_SECRET', 't7QkJeQsrwQJQiMr');
define('SHORTCODE', '600984');
define('PASSKEY', 'YOUR_PASSKEY');
define('CALLBACK_URL', 'https://localhost/mpesa/stk_push.php/callback_url'); // Your callback URL
?>
<?php
function getAccessToken() {
    $consumerKey = CONSUMER_KEY;
    $consumerSecret = CONSUMER_SECRET;

    $credentials = base64_encode($consumerKey . ':' . $consumerSecret);
    $url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, ['Authorization: Basic ' . $credentials]);
    curl_setopt($curl, CURLOPT_HEADER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    $curl_response = curl_exec($curl);
    $result = json_decode($curl_response);

    return $result->access_token;
}
?>
